<?php

function cong2mang($a, $b) {
    if (count($a) != count($b)) {
        echo "Lỗi: Hai mảng không cùng độ dài!";
        return;
    }

    $c = [];

    for ($i = 0; $i < count($a); $i++) {
        $c[$i] = $a[$i] + $b[$i];
    }

    return $c;
}

$a = [344, 224, 223, 7737, 9922, -828];
$b = [-344, -324, 123, 773, -9922, 828];

$c = cong2mang($a, $b);

if ($c != null) {
    echo "Mảng kết quả: ";
    print_r($c);
}

?>
