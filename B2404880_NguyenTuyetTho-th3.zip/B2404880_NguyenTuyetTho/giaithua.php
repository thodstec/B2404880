<?php
// function giaithua($n){
//     if($n == 0 || $n == 1){
//         return 1;
//     }

//     return $n * giaithua($n -1);
// }

// echo "10! = " . giaithua(10);


function giaithua($n) {
    $gt = 1;

    for ($i = 1; $i <= $n; $i++) {
        $gt = $gt * $i;
    }

    return $gt;
}

$n = readline("Nhập n: ");

echo "$n! = " . giaithua($n);

?>