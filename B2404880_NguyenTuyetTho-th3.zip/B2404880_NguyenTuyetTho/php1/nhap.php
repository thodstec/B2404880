<!DOCTYPE HTML>
<html>  
<body>

<form action="welcome.php" method="post">
Name: <input type="text" name="name"><br>
E-mail: <input type="text" name="email"><br>
Password: <input type="password" name="password"><br>
Ngày tháng năm sinh: <input type="date" name="birthday"><br><br>
<input type="submit">
</form>

</body>
</html>
